CREATE TABLE Online_sales_Dataset(
    Order_ID NUMBER,
    Order_Date DATE,
    Products VARCHAR(15),
    Category VARCHAR(15),
    Region VARCHAR(10),
    Payment_Mode VARCHAR(10),
    Sales NUMBER
);

SELECT *
FROM Online_sales_Dataset;


INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2001,TO_DATE('2024-01-18','YYYY-MM-DD'),'Shoes','Electronics','East','UPI',32968);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2002,TO_DATE('2024-02-27','YYYY-MM-DD'),'Smart Watch','Home Appliances','West','CreditCard',6651);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2003,TO_DATE('2024-03-03','YYYY-MM-DD'),'Mobile','Clothing','West','UPI',46102);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2004,TO_DATE('2024-02-27','YYYY-MM-DD'),'Headphones','Home Appliances','South','UPI',59575);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2005,TO_DATE('2024-02-10','YYYY-MM-DD'),'Mobile','Electronics','North','UPI',58252);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2006,TO_DATE('2024-02-18','YYYY-MM-DD'),'T-Shirt','Electronics','West','UPI',35078);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2007,TO_DATE('2024-01-29','YYYY-MM-DD'),'Refrigerator','Clothing','West','CreditCard',23155);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2008,TO_DATE('2024-01-30','YYYY-MM-DD'),'T-Shirt','Electronics','West','Debit Card',1908);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2009,TO_DATE('2024-02-23','YYYY-MM-DD'),'Refrigerator','Home Appliances','North','CreditCard',41745);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2010,TO_DATE('2024-02-07','YYYY-MM-DD'),'Mobile','Home Appliances','East','COD',33773);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2011,TO_DATE('2024-03-26','YYYY-MM-DD'),'Laptop','Clothing','East','COD',55956);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2012,TO_DATE('2024-03-05','YYYY-MM-DD'),'Smart Watch','Home Appliances','North','COD',16408);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2013,TO_DATE('2024-02-21','YYYY-MM-DD'),'Smart Watch','Home Appliances','South','Debit Card',36466);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2014,TO_DATE('2024-03-30','YYYY-MM-DD'),'Refrigerator','Home Appliances','East','UPI',29267);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2015,TO_DATE('2024-03-25','YYYY-MM-DD'),'Shoes','Electronics','South','COD',24782);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2016,TO_DATE('2024-03-03','YYYY-MM-DD'),'T-Shirt','Electronics','West','UPI',20719);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2017,TO_DATE('2024-03-31','YYYY-MM-DD'),'Refrigerator','Home Appliances','West','CreditCard',11548);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2018,TO_DATE('2024-03-05','YYYY-MM-DD'),'Laptop','Electronics','South','CreditCard',27006);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2019,TO_DATE('2024-03-06','YYYY-MM-DD'),'Headphones','Home Appliances','East','COD',18147);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2020,TO_DATE('2024-03-25','YYYY-MM-DD'),'Shoes','Home Appliances','North','COD',51857);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2021,TO_DATE('2024-03-06','YYYY-MM-DD'),'Refrigerator','Electronics','South','COD',4178);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2022,TO_DATE('2024-03-02','YYYY-MM-DD'),'Refrigerator','Clothing','South','COD',32280);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2023,TO_DATE('2024-02-15','YYYY-MM-DD'),'Smart Watch','Clothing','North','DebitCard',30525);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2024,TO_DATE('2024-03-17','YYYY-MM-DD'),'Mobile','Electronics','South','CreditCard',56927);

INSERT INTO Online_sales_Dataset(Order_ID,Order_Date,Products,Category,Region,Payment_Mode,Sales)
VALUES(2025,TO_dATE('2024-01-12','YYYY-MM-DD'),'Refrigerator','Home Appliances','East','UPI',55664);


SELECT * FROM Online_sales_Dataset;

SELECT SUM(Sales)as Total_SAle,Region
FROM Online_sales_Dataset
GROUP BY Region 
ORDER BY Total_SAle DESC
FETCH FIRST 5 ROW ONLY;




SELECT Order_ID,Region,Payment_Mode,Sales
FROM Online_sales_Dataset
WHERE Sales IS NOT NULL;







